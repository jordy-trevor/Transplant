# Transplant

Andy: Programmer</br>
Amy: Lead Artist</br>
Trevor: Lead Programmer, Task Organizer</br>
Marco: Designer, Artist</br>
Clive: Programmer, Sound</br>

Side facing 2D game created using the Phaser game libraries. 


